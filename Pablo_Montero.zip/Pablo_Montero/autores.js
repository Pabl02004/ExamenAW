document.addEventListener('DOMContentLoaded', () => {
    const formContainer = document.getElementById('form-container');
    const authorForm = document.getElementById('author-form');
    const addAuthorBtn = document.getElementById('add-author-btn');
    const cancelBtn = document.getElementById('cancel-btn');
    const authorList = document.querySelector('.author-list');
    const searchInput = document.getElementById('search');
    let editAuthorId = null;

    addAuthorBtn.addEventListener('click', () => {
        formContainer.style.display = 'block';
        authorForm.reset(); 
        editAuthorId = null; 
    });

    cancelBtn.addEventListener('click', () => {
        formContainer.style.display = 'none';
    });

    authorForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const formData = new FormData(authorForm);
        const data = {
            Nombre: formData.get('nombre'),
            Apellido: formData.get('apellido'),
            Fecha_Nacimiento: formData.get('fecha-nacimiento'),
            Genero: formData.get('genero')
        };

        try {
            if (editAuthorId) {
                await fetch(`http://localhost:3000/api/autores/${editAuthorId}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });
            } else {
                await fetch('http://localhost:3000/api/autores', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });
            }

            formContainer.style.display = 'none';
            loadAuthors(); 
        } catch (error) {
            console.error('Error:', error);
        }
    });

    async function loadAuthors() {
        try {
            const response = await fetch('http://localhost:3000/api/autores');
            const authors = await response.json();

            authorList.innerHTML = ''; 

            authors.forEach(author => {
                const authorItem = document.createElement('div');
                authorItem.className = 'author-item';
                authorItem.innerHTML = `
                    <span class="author-nombre">${author.Nombre}</span>
                    <span class="author-apellido">${author.Apellido}</span>
                    <span class="author-fecha-nacimiento">${author.Fecha_Nacimiento}</span>
                    <span class="author-genero">${author.Genero}</span>
                    <button class="edit-btn" data-id="${author.id_Autores}">Editar</button>
                    <button class="delete-btn" data-id="${author.id_Autores}">Eliminar</button>
                `;
                authorList.appendChild(authorItem);
            });

            document.querySelectorAll('.edit-btn').forEach(button => {
                button.addEventListener('click', handleEdit);
            });

            document.querySelectorAll('.delete-btn').forEach(button => {
                button.addEventListener('click', handleDelete);
            });
        } catch (error) {
            console.error('Error:', error);
        }
    }

    function handleEdit(event) {
        const authorItem = event.target.parentNode;
        const nombre = authorItem.querySelector('.author-nombre').textContent;
        const apellido = authorItem.querySelector('.author-apellido').textContent;
        const fechaNacimiento = authorItem.querySelector('.author-fecha-nacimiento').textContent;
        const genero = authorItem.querySelector('.author-genero').textContent;

        editAuthorId = event.target.dataset.id;

        authorForm.nombre.value = nombre;
        authorForm.apellido.value = apellido;
        authorForm['fecha-nacimiento'].value = fechaNacimiento;
        authorForm.genero.value = genero;

        formContainer.style.display = 'block'; 
    }

    async function handleDelete(event) {
        const authorItem = event.target.parentNode;
        const nombre = authorItem.querySelector('.author-nombre').textContent;

        if (confirm(`¿Estás seguro de que quieres eliminar al autor "${nombre}"?`)) {
            const id = event.target.dataset.id;
            try {
                await fetch(`http://localhost:3000/api/autores/${id}`, {
                    method: 'DELETE'
                });
                loadAuthors(); // Recargar la lista de autores
            } catch (error) {
                console.error('Error:', error);
            }
        }
    }

    searchInput.addEventListener('input', () => {
        const query = searchInput.value.toLowerCase();
        const authorItems = document.querySelectorAll('.author-item');

        authorItems.forEach(item => {
            const nombre = item.querySelector('.author-nombre').textContent.toLowerCase();
            const apellido = item.querySelector('.author-apellido').textContent.toLowerCase();
            const fechaNacimiento = item.querySelector('.author-fecha-nacimiento').textContent.toLowerCase();
            const genero = item.querySelector('.author-genero').textContent.toLowerCase();

            if (nombre.includes(query) || apellido.includes(query) || fechaNacimiento.includes(query) || genero.includes(query)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    });

    loadAuthors();
});
