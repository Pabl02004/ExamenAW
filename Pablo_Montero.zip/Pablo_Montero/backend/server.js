const express = require('express');
const sql = require('mssql');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require("path");


const app = express();
const port = 3000;

app.use(cors()); 

app.use(bodyParser.json()); 

app.use(express.static(path.join(__dirname, "../")));


const dbConfig = {
    user: 'Pablito2',        
    password: 'Pablitomontero19',  
    server: 'PABLO',      
    database: 'Librosexamen',
    options: {
        encrypt: false,         
        trustServerCertificate: false
    }
};

sql.connect(dbConfig, err => {
    if (err) {
        console.error('Error de conexión:', err);
        process.exit(1);
    }
    console.log('Conectado a SQL Server');
});

app.get("/", (req, res) => {
    res.sendFile(path.join(_dirname, "../index.html"));

})
app.get('/api/libros', async (req, res) => {
    try {
        const result = await sql.query('SELECT * FROM Libros');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

app.post('/api/libros', async (req, res) => {
    const { titulo, Fecha_Publicacion, Precio, genero } = req.body;
    try {
        const result = await sql.query`
            INSERT INTO Libros (titulo, Fecha_Publicacion, Precio, genero)
            VALUES (${titulo}, ${Fecha_Publicacion}, ${Precio}, ${genero});
        `;
        res.json({ id_Libro: result.recordset.insertId });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

app.put('/api/libros/:id', async (req, res) => {
    const { id } = req.params;
    const { titulo, Fecha_Publicacion, Precio, genero } = req.body;
    try {
        await sql.query`
            UPDATE Libros
            SET titulo = ${titulo}, Fecha_Publicacion = ${Fecha_Publicacion}, Precio = ${Precio}, genero = ${genero}
            WHERE id_Libro = ${id};
        `;
        res.json({ message: 'Libro actualizado' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

app.delete('/api/libros/:id', async (req, res) => {
    const { id } = req.params;
    try {
        await sql.query`
            DELETE FROM Libros
            WHERE id_Libro = ${id};
        `;
        res.json({ message: 'Libro eliminado' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

//--------------- Autores

app.get('/api/autores', async (req, res) => {
    try {
        const result = await sql.query('SELECT * FROM Autores');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

app.post('/api/autores', async (req, res) => {
    const { Nombre, Apellido, Fecha_Nacimiento, Genero } = req.body;
    try {
        const result = await sql.query`
            INSERT INTO Autores (Nombre, Apellido, Fecha_Nacimiento, Genero)
            VALUES (${Nombre}, ${Apellido}, ${Fecha_Nacimiento}, ${Genero});
        `;
        res.json({ id_Autores: result.recordset.insertId });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

app.put('/api/autores/:id', async (req, res) => {
    const { id } = req.params;
    const { Nombre, Apellido, Fecha_Nacimiento, Genero } = req.body;
    try {
        await sql.query`
            UPDATE Autores
            SET Nombre = ${Nombre}, Apellido = ${Apellido}, Fecha_Nacimiento = ${Fecha_Nacimiento}, Genero = ${Genero}
            WHERE id_Autores = ${id};
        `;
        res.json({ message: 'Autor actualizado' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

app.delete('/api/autores/:id', async (req, res) => {
    const { id } = req.params;
    try {
        await sql.query`
            DELETE FROM Autores
            WHERE id_Autores = ${id};
        `;
        res.json({ message: 'Autor eliminado' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

app.listen(port, () => {
    console.log(`Servidor corriendo en http://localhost:${port}`);
});


