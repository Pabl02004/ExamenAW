document.addEventListener('DOMContentLoaded', function() {
    const addButton = document.getElementById('add-book-btn');
    const formContainer = document.getElementById('form-container');
    const cancelButton = document.getElementById('cancel-btn');
    let editBookId = null; 

    addButton.addEventListener('click', function() {
        formContainer.style.display = 'block';
        bookForm.reset(); 
        editBookId = null; 
    });

    cancelButton.addEventListener('click', function() {
        formContainer.style.display = 'none';
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const formContainer = document.getElementById('form-container');
    const bookForm = document.getElementById('book-form');
    const addBookBtn = document.getElementById('add-book-btn');
    const cancelBtn = document.getElementById('cancel-btn');
    const bookList = document.querySelector('.book-list');
    const searchInput = document.getElementById('search');
    let editBookId = null;


    addBookBtn.addEventListener('click', () => {
        formContainer.style.display = 'block';
        bookForm.reset(); 
        editBookId = null; 
    });

    cancelBtn.addEventListener('click', () => {
        formContainer.style.display = 'none';
    });

    bookForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const formData = new FormData(bookForm);
        const data = {
            titulo: formData.get('title'),
            Fecha_Publicacion: formData.get('publication-date'),
            Precio: formData.get('price'),
            genero: formData.get('genre')
        };

        try {
            if (editBookId) {
                await fetch(`http://localhost:3000/api/libros/${editBookId}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });
            } else {
                await fetch('http://localhost:3000/api/libros', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });
            }

            formContainer.style.display = 'none';
            loadBooks(); 
        } catch (error) {
            console.error('Error:', error);
        }
    });

    async function loadBooks() {
        try {
            const response = await fetch('http://localhost:3000/api/libros');
            const books = await response.json();

            bookList.innerHTML = ''; 

            books.forEach(book => {
                const bookItem = document.createElement('div');
                bookItem.className = 'book-item';
                bookItem.innerHTML = `
                    <span class="book-title">${book.titulo}</span>
                    <span class="book-publication-date">${book.Fecha_Publicacion}</span>
                    <span class="book-price">${book.Precio}</span>
                    <span class="book-genre">${book.genero}</span>
                    <button class="edit-btn" data-id="${book.id_Libro}">Editar</button>
                    <button class="delete-btn" data-id="${book.id_Libro}">Eliminar</button>
                `;
                bookList.appendChild(bookItem);
            });

            document.querySelectorAll('.edit-btn').forEach(button => {
                button.addEventListener('click', handleEdit);
            });

            document.querySelectorAll('.delete-btn').forEach(button => {
                button.addEventListener('click', handleDelete);
            });
        } catch (error) {
            console.error('Error:', error);
        }
    }

    async function handleEdit(event) {
        const bookItem = event.target.parentNode;
        const title = bookItem.querySelector('.book-title').textContent;
        const publicationDate = bookItem.querySelector('.book-publication-date').textContent;
        const price = bookItem.querySelector('.book-price').textContent;
        const genre = bookItem.querySelector('.book-genre').textContent;

        editBookId = event.target.dataset.id;

        bookForm.title.value = title;
        bookForm['publication-date'].value = publicationDate;
        bookForm.price.value = price;
        bookForm.genre.value = genre;

        formContainer.style.display = 'block'; 
    }

    async function handleDelete(event) {
        const bookItem = event.target.parentNode;
        const title = bookItem.querySelector('.book-title').textContent;

        if (confirm(`¿Estás seguro de que quieres eliminar el libro "${title}"?`)) {
            const id = event.target.dataset.id;
            try {
                await fetch(`http://localhost:3000/api/libros/${id}`, {
                    method: 'DELETE'
                });
                loadBooks(); 
            } catch (error) {
                console.error('Error:', error);
            }
        }
    }

    searchInput.addEventListener('input', () => {
        const query = searchInput.value.toLowerCase();
        const bookItems = document.querySelectorAll('.book-item');

        bookItems.forEach(item => {
            const title = item.querySelector('.book-title').textContent.toLowerCase();
            const publicationDate = item.querySelector('.book-publication-date').textContent.toLowerCase();
            const price = item.querySelector('.book-price').textContent.toLowerCase();
            const genre = item.querySelector('.book-genre').textContent.toLowerCase();

            if (title.includes(query) || publicationDate.includes(query) || price.includes(query) || genre.includes(query)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    });

    loadBooks();
});
